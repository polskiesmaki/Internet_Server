<?php
interface IntPKontakt
{
    public function getRolle(): string;
    public function toString(): string;
}