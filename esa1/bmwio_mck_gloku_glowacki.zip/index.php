<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
	<title>Main</title>
	</head>
	<body>
		<header> <h1>Main</h1> </header>
		<nav>
		 <ul>
			<li><?php echo"<a href='index.php'>Main</a>"; ?></li>
			<li><?php echo"<a href='next.php'>Projektkontakt</a>"; ?></li>
			<li><?php echo"<a href='next2.php'>Fill Data</a>"; ?></li>
			

		 </ul>
		</nav>
		
		<section>
			<p>
			Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
			sed diam nonumy eirmod tempor invidunt ut labore et dolore magna
			aliquyam erat, sed diam voluptua. At vero eos et accusam et justo
			duo dolores et ea rebum. Stet clita kasd gubergren,
			no sea takimata sanctus est Lorem ipsum dolor sit amet. 
			Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
			sed diam nonumy eirmod tempor invidunt ut labore et dolore 
			magna aliquyam erat, sed diam voluptua. At vero eos et accusam et 
			justo duo dolores et ea rebum. Stet clita kasd gubergren, 
			no sea takimata sanctus est Lorem ipsum dolor sit amet.
			</p>


			<p>
			Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
			sed diam nonumy eirmod tempor invidunt ut labore et dolore magna
			aliquyam erat, sed diam voluptua. At vero eos et accusam et justo
			duo dolores et ea rebum. Stet clita kasd gubergren,
			no sea takimata sanctus est Lorem ipsum dolor sit amet. 
			Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
			sed diam nonumy eirmod tempor invidunt ut labore et dolore 
			magna aliquyam erat, sed diam voluptua. At vero eos et accusam et 
			justo duo dolores et ea rebum. Stet clita kasd gubergren, 
			no sea takimata sanctus est Lorem ipsum dolor sit amet.
			</p>
			<img src="test.png"/>
			<p>
			Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
			sed diam nonumy eirmod tempor invidunt ut labore et dolore magna
			aliquyam erat, sed diam voluptua. At vero eos et accusam et justo
			duo dolores et ea rebum. Stet clita kasd gubergren,
			no sea takimata sanctus est Lorem ipsum dolor sit amet.
			</p>
			</br>
		</section>
	</body>
</html>